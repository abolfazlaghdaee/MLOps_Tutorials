#!/bin/sh

if [ ! -d "learning" ]
then


  mkdir learning
else
  echo "Directory 'learning' already exists."
fi
