#!/bin/bash



animals="man bear pig  dog cat sheep"

for animal in $animals
do
	echo "$animal"

done
